import ThreeGlobe from "three-globe";
import { WebGLRenderer, Scene, Vector3, MathUtils } from "three";
import {
  PerspectiveCamera,
  AmbientLight,
  DirectionalLight,
  Color,
  Fog,
  PointLight,
} from "three";
import { OrbitControls } from "three/examples/jsm/controls/OrbitControls.js";
import countries from "./files/globe-data-min.json"; // Ensure this JSON file is correctly loaded

// Custom locations: Bhavnagar (Gujarat) and Sudbury (Canada)
const customLocations = [
  { city: "Bhavnagar", lat: 21.7645, lng: 72.1519, size: 1 }, // Bhavnagar, Gujarat
  { city: "Sudbury", lat: 46.4900, lng: -81.0100, size: 1 },  // Sudbury, Canada
];

// Arc data: One arc is green, the other is yellow
const arcData = [
  { startLat: 21.7645, startLng: 72.1519, endLat: 46.4900, endLng: -81.0100, color: "green" }, // Bhavnagar to Sudbury (green)
  { startLat: 46.4900, startLng: -81.0100, endLat: 21.7645, endLng: 72.1519, color: "yellow" }  // Sudbury to Bhavnagar (yellow)
];

var renderer, camera, scene, controls;
let mouseX = 0;
let mouseY = 0;
let windowHalfX = window.innerWidth / 2;
let windowHalfY = window.innerHeight / 2;
var Globe;

init();
initGlobe();
onWindowResize();
animate();
rotateToSudbury(); // Start the rotation when the globe loads

// SECTION Initializing core ThreeJS elements
function init() {
  // Initialize renderer
  renderer = new WebGLRenderer({ antialias: true });
  renderer.setPixelRatio(window.devicePixelRatio);
  renderer.setSize(window.innerWidth, window.innerHeight);
  document.body.appendChild(renderer.domElement);

  // Initialize scene, light
  scene = new Scene();
  scene.add(new AmbientLight(0xbbbbbb, 0.3));
  scene.background = new Color(0x040d21);

  // Initialize camera, light
  camera = new PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
  camera.position.set(400, 0, 0); // Set initial camera position near Bhavnagar
  scene.add(camera);

  // Add directional lights
  var dLight = new DirectionalLight(0xffffff, 0.4);
  dLight.position.set(-800, 2000, 400);
  camera.add(dLight);

  var dLight1 = new DirectionalLight(0x7982f6, 1);
  dLight1.position.set(-200, 500, 200);
  camera.add(dLight1);

  var dLight2 = new PointLight(0x8566cc, 0.2);
  dLight2.position.set(-200, 500, 200);
  camera.add(dLight2);

  // Additional effects
  scene.fog = new Fog(0x535ef3, 400, 2000);

  // Initialize controls
  controls = new OrbitControls(camera, renderer.domElement);
  controls.enableDamping = true;
  controls.dynamicDampingFactor = 0.01;
  controls.enablePan = false;
  controls.minDistance = 300; // Adjusted min distance
  controls.maxDistance = 500; // Optional adjustment
  controls.rotateSpeed = 0.8;
  controls.enableZoom = false; // Disable zooming for better control

  // Enable auto-rotation of the globe
  controls.autoRotate = true;
  controls.autoRotateSpeed = 7;

  controls.minPolarAngle = Math.PI / 3.5;
  controls.maxPolarAngle = Math.PI - Math.PI / 3;

  window.addEventListener("resize", onWindowResize, true);
}

// SECTION Globe
function initGlobe() {
  // Initialize the Globe and ensure country data is loaded correctly
  Globe = new ThreeGlobe({ 
    waitForGlobeReady: true,
    animateIn: true
  })
    .hexPolygonsData(countries.features) // Make sure this is correct and loaded properly
    .hexPolygonResolution(3) 
    .hexPolygonMargin(0.7) 
    .showAtmosphere(true)
    .atmosphereColor("#3a228a")
    .atmosphereAltitude(0.25)
    .hexPolygonColor(() => "rgba(255, 255, 255, 0.3)"); // Make countries visible

  // Add Bhavnagar and Sudbury to the points data and labels
  Globe.pointsData(customLocations)
    .pointColor(() => "#ffcb21") // Point color for the locations
    .pointsMerge(true)
    .pointAltitude(0.05)
    .pointRadius(0.7); // Increased size of the pins (was 0.3, now 0.7 for larger size)

  Globe.labelsData(customLocations)
    .labelColor(() => "#ffffff") // Label color
    .labelText("city")           // Display city names
    .labelSize(() => 7)        // Size of the label text
    .labelResolution(6)
    .labelAltitude(0.01);        // How high above the globe the label should be

  // Add moving arcs between Bhavnagar and Sudbury in both directions
  Globe.arcsData(arcData)
    .arcColor((e) => e.color)        // Color of the arcs (green for one, yellow for the other)
    .arcAltitude(0.2)               // Altitude for the arcs
    .arcStroke(2)                   // Increased thickness of the arcs
    .arcDashLength(0.5)             // Length of each dash
    .arcDashGap(2)                  // Gap between dashes
    .arcDashInitialGap(0)           // Start the dash with no gap
    .arcDashAnimateTime(2000)       // Animation time (speed)
    .arcsTransitionDuration(1000);  // Duration for transitions

  // Rotate and set globe appearance so Bhavnagar is more central
  Globe.rotateY(Math.PI * 0.5); // Rotate so Bhavnagar is visible more prominently
  Globe.rotateZ(Math.PI / 10); // Adjust the tilt so Sudbury is not on the top
  const globeMaterial = Globe.globeMaterial();
  globeMaterial.color = new Color(0x3a228a);
  globeMaterial.emissive = new Color(0x220038);
  globeMaterial.emissiveIntensity = 0.1;
  globeMaterial.shininess = 0.7;

  // Set the size of the globe
  Globe.scale.set(0.9, 0.9, 0.9);

  scene.add(Globe);

  // Start the animation from Bhavnagar to Sudbury after the globe is loaded
  rotateToSudbury(); // Call this function after globe is initialized
}

// Rotate the globe from Bhavnagar to Sudbury
function rotateToSudbury() {
  const bhavnagarLatLng = { lat: 21.7645, lng: 72.1519 };
  const sudburyLatLng = { lat: 46.4900, lng: -81.0100 };

  // Convert lat/lng to spherical coordinates (x, y, z) for both locations
  const fromCoords = latLngToSphericalCoords(bhavnagarLatLng.lat, bhavnagarLatLng.lng);
  const toCoords = latLngToSphericalCoords(sudburyLatLng.lat, sudburyLatLng.lng);

  // Animate the camera rotation from Bhavnagar to Sudbury
  const duration = 4000; // 4 seconds animation
  const startTime = performance.now();

  function animateRotation(time) {
    const elapsedTime = time - startTime;
    const t = MathUtils.clamp(elapsedTime / duration, 0, 1);

    // Interpolate camera position between Bhavnagar and Sudbury
    const currentPosition = new Vector3().lerpVectors(fromCoords, toCoords, t);
    camera.position.copy(currentPosition);

    camera.lookAt(new Vector3(0, 0, 0)); // Look at the center of the globe

    if (t < 1) {
      requestAnimationFrame(animateRotation);
    }
  }

  requestAnimationFrame(animateRotation);
}

// Convert latitude/longitude to spherical coordinates (x, y, z)
function latLngToSphericalCoords(lat, lng) {
  const radius = 400; // Globe radius
  const phi = (90 - lat) * (Math.PI / 180); // Convert latitude to polar angle
  const theta = (lng + 180) * (Math.PI / 180); // Convert longitude to azimuthal angle

  const x = radius * Math.sin(phi) * Math.cos(theta);
  const y = radius * Math.cos(phi);
  const z = radius * Math.sin(phi) * Math.sin(theta);

  return new Vector3(x, y, z);
}

function onWindowResize() {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
}

function animate() {
  camera.position.x +=
    Math.abs(mouseX) <= windowHalfX / 2
      ? (mouseX / 4 - camera.position.x) * 0.005 // Reduced movement speed
      : 0;
  camera.position.y += (-mouseY / 4 - camera.position.y) * 0.005; // Reduced movement speed
  camera.lookAt(scene.position);
  controls.update();
  renderer.render(scene, camera);
  requestAnimationFrame(animate);
}
